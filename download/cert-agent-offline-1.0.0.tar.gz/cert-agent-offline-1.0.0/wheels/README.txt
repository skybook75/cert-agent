이 폴더는 인터넷 PC에서 prepare/prepare_online.(sh|ps1) 을 실행하면 채워집니다.
OS 패키지 python3-cryptography 가 있고 벡터 DB 를 안 쓰면 비워 둬도 됩니다.
