임베딩 모델(약 230MB) — 벡터 DB(--vector)를 쓸 때만 필요합니다. prepare_online 으로 채웁니다.
